package user.library.librarymanagementusingbasicauth.utility;

public enum Category {
	ADMINUSER,LOCALUSER
}
