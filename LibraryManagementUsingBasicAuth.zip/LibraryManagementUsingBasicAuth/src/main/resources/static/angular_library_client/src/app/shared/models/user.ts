export class User {
	userId: number;
	email: string;
	password: string;
	category:string;
}
