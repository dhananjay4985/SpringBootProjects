export class Book {
	bookId: number;
	bookName:string;
	author: string;
	isbn: string;
	genre:string;
}
