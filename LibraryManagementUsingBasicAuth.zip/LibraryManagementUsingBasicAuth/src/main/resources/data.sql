insert into book("bookid","bookname","author","genre","isbn") values(1,"Core Java","Sam","99921-58-10-7");
insert into book("bookid","bookname","author","genre","isbn") values(2,"Advance Java","peter","0-943396-04-2");
insert into book("bookid","bookname","author","genre","isbn") values(3,"Angular 6","max","85-359-0277-5");
insert into book("bookid","bookname","author","genre","isbn") values(4,"Python","Aj","0-684-84328-5");

insert into user("userid","email","password","category") values(1,"dj@gmail.com","abc123","admin");
insert into user("userid","email","password","category") values(2,"dhanish@gmail.com","xyz","admin");
insert into user("userid","email","password","category") values(3,"vinod@gmail.com","pqr","local");